
> ?A  README.md for code accompanying a Minimax Optimization:The Case of Convex-Submodular paper

# Minimax Optimization:The Case of Convex-Submodular
Movie recommendation application


## Requirements
The main code file movrecomadversarialdesign.py can be run in python.
matrixuserrate.csv is the matrix of ratings

## Results
we include all the results in paper.
